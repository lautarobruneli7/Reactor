# Simulador Químico

Simulador visual de formulación y calidad de productos químicos y farmacéuticos. El usuario elige una reacción, arma la mezcla (reactivos, catalizador, excipiente), ajusta cantidades y purezas, y el programa calcula la estequiometría y estima rendimiento, pureza y un puntaje de calidad en tiempo real. El caso de partida es el **ibuprofeno**, pero el catálogo ya trae más de 130 sustancias, los 118 elementos y 11 reacciones, y los cálculos sirven para cualquier fórmula.

> **Alcance:** es una herramienta de **estimación**. El puntaje mide la calidad de la mezcla y del producto estimado (rendimiento, pureza, balance estequiométrico). **No mide eficacia clínica**: eso depende de la dosis, la biodisponibilidad, la farmacocinética y los ensayos clínicos. Todos los parámetros actuales son supuestos didácticos **sin validar** (ver `docs/`).

## Estructura

```
simulador-quimico/
├── backend/                 API y motor de cálculo (Python + FastAPI)
│   ├── pyproject.toml
│   ├── app/
│   │   ├── main.py          entrada de FastAPI
│   │   ├── api/             rutas HTTP (compuestos, simulación)
│   │   ├── core/            motor de cálculo
│   │   │   ├── formulas.py         fórmula → composición y peso molecular (cualquier sustancia)
│   │   │   ├── balanceo.py         balanceo de ecuaciones por conservación de átomos
│   │   │   ├── reacciones.py       validación de reacciones contra el catálogo
│   │   │   ├── estequiometria.py   moles, reactivo limitante, excesos, economía atómica
│   │   │   ├── pureza.py           efecto de pureza y catalizador
│   │   │   ├── formulacion.py      principio activo vs. excipientes
│   │   │   ├── calidad.py          puntaje y cumplimiento de especificaciones
│   │   │   ├── propiedades.py      propiedades moleculares con RDKit (opcional)
│   │   │   └── simulador.py        orquesta todo lo anterior
│   │   ├── models/schemas.py       esquemas Pydantic
│   │   ├── db/                     SQLite: database.py y seed.py
│   │   └── data/                   elementos, compuestos, categorías, reacciones y especificaciones (JSON)
│   ├── scripts/             construye el catálogo verificándolo contra fuentes públicas
│   └── tests/
├── frontend/                Interfaz (React + TypeScript + Vite)
│   └── src/
│       ├── api/  hooks/  types/  styles/
│       └── components/      Reactor, Compuestos, Controles, Resultados
├── prototipos/              Prototipos HTML de un solo archivo (2D y 3D)
└── docs/                    Fuentes de datos, supuestos del modelo, próximos pasos
```

## Cómo correrlo

Necesitás **Python 3.10+** y **Node 18+**.

**1. Backend** (puerto 8000)

```bash
cd backend
python -m venv .venv
source .venv/bin/activate          # en Windows: .venv\Scripts\activate
pip install -e ".[dev,quimica]"    # "quimica" instala RDKit; es opcional (no hace falta para el catálogo)
uvicorn app.main:app --reload --port 8000
```

La documentación interactiva de la API queda en <http://127.0.0.1:8000/docs>.

**2. Frontend** (puerto 5173), en otra terminal

```bash
cd frontend
npm install
npm run dev
```

Abrí <http://localhost:5173>. Tocá **Cargar ejemplo**: tiene que dar un puntaje de **85**.

**3. Tests del backend**

```bash
cd backend
pytest
```

## API

| Método | Ruta | Qué hace |
|---|---|---|
| GET | `/api/salud` | Estado del servicio y si RDKit está disponible |
| GET | `/api/compuestos` | Catálogo, con `q` (nombre, fórmula, CAS o sinónimo; sin importar acentos), `categoria`, `fase`, `acceso`, `tipo`, `limit` y `offset`. El total va en el encabezado `X-Total-Count` |
| GET | `/api/categorias` | Categorías de la biblioteca y cuántos compuestos tiene cada una |
| GET | `/api/compuestos/{id}` | Un compuesto |
| GET | `/api/compuestos/{id}/propiedades` | Propiedades estimadas con RDKit |
| GET | `/api/elementos`, `/api/elementos/{símbolo}` | Tabla periódica (118 elementos, masas NIST) |
| GET | `/api/formulas/pm?formula=…` | Peso molecular y composición porcentual de **cualquier** fórmula (admite hidratos y paréntesis) |
| POST | `/api/estequiometria/balancear` | Balancea una ecuación a partir de las fórmulas |
| GET | `/api/reacciones` | Reacciones del catálogo (con `?compuesto=id` se filtran las que lo usan) |
| GET | `/api/reacciones/{id}` | Una reacción con su ecuación y parámetros |
| GET | `/api/especificaciones` | Especificaciones de calidad cargadas |
| GET | `/api/reaccion` | Reacción en uso por defecto (ibuprofeno) |
| POST | `/api/simulacion` | Simula una mezcla con la reacción elegida (`reaccion_id`) y devuelve resultado y alertas. Opcional: `rendimiento_real_pct` para usar un rendimiento medido |

Ejemplo:

```bash
curl -X POST http://127.0.0.1:8000/api/simulacion \
  -H "Content-Type: application/json" \
  -d '{"componentes":[{"id":"ibb","gramos":134,"pureza":99},{"id":"aa","gramos":102,"pureza":98},{"id":"cat","gramos":20,"pureza":97},{"id":"h2","gramos":2,"pureza":99},{"id":"co","gramos":28,"pureza":98},{"id":"exc","gramos":30,"pureza":99}]}'
```

## Catálogo de datos

El catálogo vive en `backend/app/data/` y se regenera con un script que **verifica cada dato** antes de guardarlo (CAS contra fórmula, peso molecular calculado contra la base pública, fase contra puntos de fusión y ebullición):

```bash
pip install -e ".[datos]"
python scripts/construir_datos.py
```

La lista de sustancias que entran la define una persona en `backend/scripts/semilla_catalogo.py`. Las reglas de qué entra y qué no están en `docs/politica-de-sustancias.md`. Al arrancar, el backend valida todo (incluido que cada reacción conserve los átomos) y rehace la base SQLite; si algo está mal, no arranca.

## Prototipos

En `prototipos/` hay dos archivos HTML autónomos (se abren con doble clic, sin instalar nada):

- `simulador-quimico-2d.html`: primera versión, interfaz plana.
- `simulador-quimico-3d.html`: versión con escena 3D (reactor de vidrio, partículas, molécula, columnas). Es la referencia visual para migrar a React.

El motor del backend reproduce exactamente los números de estos prototipos (hay tests que lo comprueban).

## Documentación

- `docs/supuestos-del-modelo.md`: cómo se calcula cada cosa y qué simplifica.
- `docs/fuentes-de-datos.md`: de dónde sale cada dato y su estado de validación.
- `docs/politica-de-sustancias.md`: qué sustancias entran al catálogo, cuáles no y cómo se marcan las fiscalizadas.
- `docs/preguntas-para-bioquimica.md`: preguntas para validar el enfoque con una persona del área.
- `docs/proximos-pasos.md`: hoja de ruta.
