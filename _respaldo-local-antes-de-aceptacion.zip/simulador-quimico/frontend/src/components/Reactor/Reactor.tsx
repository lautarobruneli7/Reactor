import { useMemo, useState } from 'react';
import type { ComponenteEnReactor, Compuesto, Reaccion, Resultado } from '../../types';
import { Formula } from '../Compuestos/categorias';
import { colorDe, colorNumDe, liquidoDe } from '../Compuestos/colores';
import { ControlCompuesto } from '../Controles/ControlCompuesto';
import { Escena3D } from './Escena3D';
import type { EstadoEscena } from './motor3d';

interface Props {
  numero: number;
  componentes: ComponenteEnReactor[];
  catalogo: Compuesto[];
  resultado: Resultado | null;
  reacciones: Reaccion[];
  reaccion: Reaccion | null;
  onReaccion: (id: string) => void;
  onAgregar: (id: string) => void;
  onCambiar: (uid: number, cambios: Partial<Pick<ComponenteEnReactor, 'gramos' | 'pureza'>>) => void;
  onQuitar: (uid: number) => void;
  onEjemplo: () => void;
  onVaciar: () => void;
}

/** Columna central: el reactor 3D (zona para soltar compuestos) y la carga con sus controles. */
export function Reactor({ numero, componentes, catalogo, resultado, reacciones, reaccion, onReaccion, onAgregar, onCambiar, onQuitar, onEjemplo, onVaciar }: Props) {
  const [arrastrando, setArrastrando] = useState(false);
  const [giro, setGiro] = useState(true);
  const [vistaKey, setVistaKey] = useState(0);
  const porId = useMemo(() => new Map(catalogo.map((c) => [c.id, c])), [catalogo]);

  const estado = useMemo<EstadoEscena>(
    () => ({
      items: componentes.flatMap((x) => {
        const c = porId.get(x.id);
        return c
          ? [{ id: x.id, gramos: x.gramos, pm: c.pm, fase: c.fase, color: colorNumDe(x.id), liquido: liquidoDe(x.id) }]
          : [];
      }),
      resultado,
    }),
    [componentes, porId, resultado],
  );

  const total = componentes.reduce((s, x) => s + x.gramos, 0);

  return (
    <div className="columna">
      <section
        className={`panel${arrastrando ? ' sobre' : ''}`}
        onDragOver={(e) => {
          e.preventDefault();
          setArrastrando(true);
        }}
        onDragLeave={() => setArrastrando(false)}
        onDrop={(e) => {
          e.preventDefault();
          setArrastrando(false);
          onAgregar(e.dataTransfer.getData('text/plain'));
        }}
      >
        <div className="panel-cabecera">
          <h2 className="titulo-panel grande">
            Reactor <span className="mono sub">N° {String(numero).padStart(3, '0')}</span>
          </h2>
          <div className="segmentado" role="group" aria-label="Cámara">
            <button className={giro ? 'on' : ''} aria-pressed={giro} onClick={() => setGiro(!giro)}>
              Girar
            </button>
            <button onClick={() => setVistaKey((k) => k + 1)}>Vista 3D</button>
          </div>
        </div>

        {reacciones.length > 0 && (
          <div className="selector-reaccion">
            <label className="nota" htmlFor="reaccion">Reacción</label>
            <select id="reaccion" className="campo" value={reaccion?.id ?? ''} onChange={(e) => onReaccion(e.target.value)}>
              {reacciones.map((r) => (
                <option key={r.id} value={r.id}>{r.nombre}</option>
              ))}
            </select>
            {reaccion && <div className="mono nota ecuacion"><Formula texto={reaccion.ecuacion} /></div>}
          </div>
        )}

        <Escena3D estado={estado} giro={giro} vistaKey={vistaKey} />
        {componentes.length === 0 && <p className="pista">Soltá acá los compuestos de la biblioteca.</p>}

        <div className="composicion">
          <div className="composicion-cabecera">
            <span>Composición de la carga</span>
            <strong className="mono">{total} g</strong>
          </div>
          <div className="composicion-barra">
            {componentes
              .filter((x) => x.gramos > 0)
              .map((x) => (
                <span
                  key={x.uid}
                  style={{ flexGrow: x.gramos, background: colorDe(x.id) }}
                  title={`${porId.get(x.id)?.nombre ?? x.id}: ${x.gramos} g`}
                />
              ))}
          </div>
        </div>
      </section>

      <section className="panel">
        <div className="panel-cabecera">
          <h2 className="titulo-panel grande">Carga</h2>
          <div className="acciones">
            <button className="btn btn-contorno" onClick={onEjemplo}>
              Cargar ejemplo
            </button>
            <button className="btn btn-contorno" onClick={onVaciar} disabled={componentes.length === 0}>
              Vaciar
            </button>
          </div>
        </div>
        {componentes.length === 0 ? (
          <p className="vacio">El reactor está vacío. Agregá compuestos desde la biblioteca.</p>
        ) : (
          componentes.map((x) => {
            const c = porId.get(x.id);
            return c ? (
              <ControlCompuesto key={x.uid} componente={x} compuesto={c} onCambiar={onCambiar} onQuitar={onQuitar} />
            ) : null;
          })
        )}
      </section>
    </div>
  );
}
