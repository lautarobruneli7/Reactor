export type Seccion = 'reactor' | 'biblioteca' | 'ensayos';

const SECCIONES: Array<[Seccion, string]> = [
  ['reactor', 'Reactor'],
  ['biblioteca', 'Biblioteca'],
  ['ensayos', 'Ensayos'],
];

interface Props {
  seccion: Seccion;
  onSeccion: (s: Seccion) => void;
  numero: number;
  producto: string;
  onGuardar: () => void;
  puedeGuardar: boolean;
  avisoGuardado: boolean;
}

export function Cabecera({ seccion, onSeccion, numero, producto, onGuardar, puedeGuardar, avisoGuardado }: Props) {
  return (
    <header className="cabecera">
      <div className="marca">
        <span className="marca-logo" aria-hidden>
          <svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M9 3h6M10 3v6.5L5.4 18a2 2 0 0 0 1.8 3h9.6a2 2 0 0 0 1.8-3L14 9.5V3" />
            <path d="M7.5 15h9" />
          </svg>
        </span>
        <span className="marca-nombre">Retorta</span>
      </div>

      <nav className="pestanas" aria-label="Secciones">
        {SECCIONES.map(([id, nombre]) => (
          <button
            key={id}
            className={`pestana${seccion === id ? ' activa' : ''}`}
            onClick={() => onSeccion(id)}
            aria-current={seccion === id ? 'page' : undefined}
          >
            {nombre}
          </button>
        ))}
      </nav>

      <div className="cabecera-der">
        <span className="chip-ensayo">
          <span className="mono">N° {String(numero).padStart(3, '0')}</span> <strong>{producto}</strong>
        </span>
        <button className="btn btn-primario" onClick={onGuardar} disabled={!puedeGuardar}>
          {avisoGuardado ? '✓ Guardado' : 'Guardar ensayo'}
        </button>
      </div>
    </header>
  );
}
