import type { ComponenteEnReactor, Compuesto } from '../../types';
import { colorDe } from '../Compuestos/colores';

interface Props {
  componente: ComponenteEnReactor;
  compuesto: Compuesto;
  onCambiar: (uid: number, cambios: Partial<Pick<ComponenteEnReactor, 'gramos' | 'pureza'>>) => void;
  onQuitar: (uid: number) => void;
}

/** Fila de la carga: cantidad (slider) y pureza (campo numérico) de un compuesto. */
export function ControlCompuesto({ componente, compuesto, onCambiar, onQuitar }: Props) {
  return (
    <div className="item-carga" style={{ ['--c' as string]: colorDe(compuesto.id) }}>
      <div className="item-linea">
        <span className="punto-color" />
        <strong className="item-nombre">{compuesto.nombre}</strong>
        <input
          type="range"
          aria-label={`Cantidad de ${compuesto.nombre}`}
          min={0}
          max={400}
          step={1}
          style={{ ['--p' as string]: `${(componente.gramos / 400) * 100}%` }}
          value={componente.gramos}
          onChange={(e) => onCambiar(componente.uid, { gramos: Number(e.target.value) })}
        />
        <output className="mono valor-g">{componente.gramos} g</output>
        <button className="btn-quitar" title="Quitar del reactor" onClick={() => onQuitar(componente.uid)}>
          ✕
        </button>
      </div>
      <label className="item-pureza">
        <span>Pureza</span>
        <input
          className="campo campo-num mono"
          type="number"
          min={80}
          max={100}
          step={0.5}
          value={componente.pureza}
          onChange={(e) => {
            const v = Number(e.target.value);
            if (Number.isFinite(v)) onCambiar(componente.uid, { pureza: Math.min(100, Math.max(0, v)) });
          }}
        />
        <span>%</span>
      </label>
    </div>
  );
}
