import { useState } from 'react';
import type { Alerta, Especificacion, Resultado } from '../../types';
import { Formula } from '../Compuestos/categorias';

interface Props {
  resultado: Resultado | null;
  alertas: Alerta[];
  cargando: boolean;
  error: string | null;
  /** Pureza mínima exigida, para marcarla sobre la barra. */
  minimoPureza: number | null;
  /** Nombre del producto principal de la reacción elegida. */
  producto: string;
  /** Rendimiento medido en un ensayo real (reemplaza al estimado); null = usar el modelo. */
  rendimientoReal: number | null;
  onRendimientoReal: (v: number | null) => void;
}

const colorDeValor = (v: number) => (v >= 75 ? 'var(--ok)' : v >= 50 ? 'var(--warn)' : 'var(--bad)');
const limitar = (v: number) => Math.max(0, Math.min(100, v));
const colorCategoria = (cat: string) =>
  cat === 'Excelente' || cat === 'Buena' ? 'var(--ok)' : cat === 'Regular' ? 'var(--warn)' : 'var(--bad)';

export function minimoDePureza(esp: Especificacion[]): number | null {
  return esp.find((e) => e.parametro.toLowerCase().includes('pureza'))?.minimo ?? null;
}

function Medidor({ valor }: { valor: number | null }) {
  const r = 52;
  const c = 2 * Math.PI * r;
  const p = valor === null ? 0 : valor / 100;
  return (
    <svg className="medidor" viewBox="0 0 120 120" role="img" aria-label="Puntaje de calidad">
      <circle cx={60} cy={60} r={r} fill="none" stroke="var(--pista)" strokeWidth={9} />
      <circle
        cx={60}
        cy={60}
        r={r}
        fill="none"
        stroke={valor === null ? 'var(--borde)' : colorDeValor(valor)}
        strokeWidth={9}
        strokeLinecap="round"
        strokeDasharray={c}
        strokeDashoffset={c * (1 - p)}
        transform="rotate(-90 60 60)"
        style={{ transition: 'stroke-dashoffset .6s, stroke .6s' }}
      />
      <text x={60} y={60} textAnchor="middle" dominantBaseline="central" className="medidor-num">
        {valor === null ? '--' : valor}
      </text>
    </svg>
  );
}

interface MetricaProps {
  etiqueta: string;
  valor: number;
  texto: string;
  sufijo?: string;
  /** Posición (0-100) de una marca, p. ej. la especificación mínima. */
  marca?: number | null;
  nota?: string;
}

function Metrica({ etiqueta, valor, texto, sufijo, marca, nota }: MetricaProps) {
  return (
    <div className="metrica">
      <div className="metrica-linea">
        <span>{etiqueta}</span>
        <strong className="mono" style={{ color: colorDeValor(valor) }}>
          {texto}
          {sufijo && <small>{sufijo}</small>}
        </strong>
      </div>
      <div className="metrica-barra">
        <div style={{ width: `${limitar(valor)}%`, background: colorDeValor(valor) }} />
        {marca != null && <i style={{ left: `${limitar(marca)}%` }} />}
      </div>
      {nota && <div className="metrica-nota">{nota}</div>}
    </div>
  );
}

/** Panel de resultados: puntaje, métricas, producto estimado, alertas y detalle técnico. */
export function Resultados({ resultado, alertas, cargando, error, minimoPureza, producto, rendimientoReal, onRendimientoReal }: Props) {
  const [detalle, setDetalle] = useState(false);
  // La barra de pureza muestra el rango 80–100 %.
  const aEscala = (p: number) => ((p - 80) / 20) * 100;

  return (
    <section className="panel resultados">
      <h2 className="titulo-panel grande">
        Resultados {cargando && <small className="cargando">calculando…</small>}
      </h2>

      {error && <div className="alerta bad">No se pudo contactar al backend. {error}</div>}

      <div className="puntaje">
        <Medidor valor={resultado ? resultado.puntaje : null} />
        <div>
          <div className="puntaje-cat" style={{ color: resultado ? colorCategoria(resultado.categoria) : 'var(--tenue)' }}>
            {resultado ? resultado.categoria : 'Sin datos'}
          </div>
          <div className="nota">Puntaje de calidad sobre 100</div>
        </div>
      </div>

      {resultado ? (
        <>
          <div className="metricas">
            <Metrica etiqueta="Rendimiento" valor={resultado.rendimiento_pct} texto={`${resultado.rendimiento_pct.toFixed(1)}%`} />
            <Metrica
              etiqueta="Pureza"
              valor={aEscala(resultado.pureza_producto_pct)}
              texto={`${resultado.pureza_producto_pct.toFixed(1)}%`}
              marca={minimoPureza != null ? aEscala(minimoPureza) : null}
              nota={minimoPureza != null ? `mínimo ${minimoPureza}%` : undefined}
            />
            <Metrica etiqueta="Balance" valor={resultado.balance_pct} texto={resultado.balance_pct.toFixed(0)} sufijo="/100" />
          </div>

          <div className="producto">
            <div className="nota">{producto} estimado</div>
            <div className="producto-valor mono">
              {resultado.gramos_estimados.toFixed(1)}
              <small>g</small>
            </div>
            <div className="nota">de {resultado.gramos_teoricos.toFixed(1)} g teóricos</div>
          </div>
        </>
      ) : (
        <p className="vacio">Agregá los reactivos de la reacción al reactor para ver el resultado.</p>
      )}

      {alertas.map((a, i) => (
        <div key={i} className={`alerta ${a.tipo}`}>
          {a.mensaje}
        </div>
      ))}

      {resultado && (
        <>
          <button className="btn btn-contorno ancho desplegable" aria-expanded={detalle} onClick={() => setDetalle(!detalle)}>
            Ver detalle técnico <span>{detalle ? '▴' : '▾'}</span>
          </button>
          {detalle && (
            <table className="tabla">
              <tbody>
                <tr><td>Reactivo limitante</td><td>{resultado.reactivo_limitante}</td></tr>
                <tr><td>Peso molecular</td><td>{resultado.pm_producto} g/mol</td></tr>
                {resultado.pct_principio_activo !== null && (
                  <tr><td>% principio activo en mezcla</td><td>{resultado.pct_principio_activo.toFixed(1)}%</td></tr>
                )}
                <tr><td>Cumple pureza mínima</td><td>{resultado.cumple_pureza ? 'Sí' : 'No'}</td></tr>
                {resultado.economia_atomica_pct !== null && (
                  <tr><td>Economía atómica</td><td>{resultado.economia_atomica_pct.toFixed(1)}%</td></tr>
                )}
                {resultado.moles_reaccion !== null && (
                  <tr><td>Avance de la reacción</td><td className="mono">{resultado.moles_reaccion.toPrecision(4)} mol</td></tr>
                )}
                <tr><td>Ecuación</td><td className="mono"><Formula texto={resultado.ecuacion} /></td></tr>
              </tbody>
            </table>
          )}
          {detalle && (
            <table className="tabla multi">
              <thead>
                <tr><th>Reactivo</th><th>Cargado</th><th>Consumido</th><th>Sobra</th></tr>
              </thead>
              <tbody>
                {resultado.reactivos.map((x) => (
                  <tr key={x.id}>
                    <td>{x.nombre}{x.limitante ? ' (limitante)' : ''}</td>
                    <td className="mono">{x.gramos_cargados.toFixed(2)} g</td>
                    <td className="mono">{x.gramos_consumidos.toFixed(2)} g</td>
                    <td className="mono">{x.gramos_sobrantes.toFixed(2)} g</td>
                  </tr>
                ))}
              </tbody>
              <thead>
                <tr><th>Producto</th><th>Teórico</th><th>Estimado</th><th /></tr>
              </thead>
              <tbody>
                {resultado.productos.map((x) => (
                  <tr key={x.id}>
                    <td>{x.nombre}{x.principal ? ' (principal)' : ''}</td>
                    <td className="mono">{x.gramos_teoricos.toFixed(2)} g</td>
                    <td className="mono">{x.gramos_estimados.toFixed(2)} g</td>
                    <td />
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          {detalle && (
            <label className="item-pureza rendimiento-real">
              <span>Rendimiento medido</span>
              <input
                className="campo campo-num mono"
                type="number"
                min={0}
                max={100}
                step={0.1}
                placeholder="—"
                value={rendimientoReal ?? ''}
                onChange={(e) => {
                  const v = e.target.value;
                  onRendimientoReal(v === '' || !Number.isFinite(Number(v)) ? null : Math.min(100, Math.max(0, Number(v))));
                }}
              />
              <span>%</span>
            </label>
          )}
        </>
      )}
    </section>
  );
}
