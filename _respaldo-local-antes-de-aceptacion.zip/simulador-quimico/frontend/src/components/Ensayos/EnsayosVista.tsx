import type { Compuesto, Ensayo } from '../../types';
import { colorDe } from '../Compuestos/colores';

interface Props {
  ensayos: Ensayo[];
  catalogo: Compuesto[];
  onCargar: (e: Ensayo) => void;
  onEliminar: (numero: number) => void;
}

const colorDeValor = (v: number) => (v >= 75 ? 'var(--ok)' : v >= 50 ? 'var(--warn)' : 'var(--bad)');
const fmt = (n: number | null, dec = 1, suf = '') => (n === null ? '—' : `${n.toFixed(dec)}${suf}`);

/** Historial de ensayos guardados: se pueden volver a cargar en el reactor o eliminar. */
export function EnsayosVista({ ensayos, catalogo, onCargar, onEliminar }: Props) {
  const nombre = (id: string) => catalogo.find((c) => c.id === id)?.nombre ?? id;

  return (
    <section className="panel">
      <div className="panel-cabecera">
        <h2 className="titulo-panel grande">Ensayos guardados</h2>
        <span className="nota">{ensayos.length} {ensayos.length === 1 ? 'ensayo' : 'ensayos'} · guardados en este navegador</span>
      </div>

      {ensayos.length === 0 ? (
        <p className="vacio">
          Todavía no guardaste ningún ensayo. Armá una mezcla en el Reactor y tocá «Guardar ensayo».
        </p>
      ) : (
        <div className="lista-ensayos">
          {ensayos.map((e) => (
            <article key={e.numero} className="ensayo">
              <div className="ensayo-num mono">N° {String(e.numero).padStart(3, '0')}</div>
              <div className="ensayo-cuerpo">
                <div className="ensayo-fecha nota">
                  {new Date(e.fecha).toLocaleString('es-AR', { dateStyle: 'medium', timeStyle: 'short' })}
                </div>
                <div className="ensayo-composicion">
                  {e.componentes.map((x) => (
                    <span key={x.id} className="chip" style={{ ['--c' as string]: colorDe(x.id) }}>
                      <span className="punto-color" />
                      {nombre(x.id)} <span className="mono">{x.gramos} g</span>
                    </span>
                  ))}
                </div>
              </div>
              <div className="ensayo-metricas">
                <div>
                  <span className="nota">Puntaje</span>
                  <strong className="mono" style={{ color: e.puntaje === null ? 'var(--tenue)' : colorDeValor(e.puntaje) }}>
                    {e.puntaje ?? '—'}
                  </strong>
                </div>
                <div><span className="nota">Rendimiento</span><strong className="mono">{fmt(e.rendimiento_pct, 1, '%')}</strong></div>
                <div><span className="nota">Pureza</span><strong className="mono">{fmt(e.pureza_producto_pct, 1, '%')}</strong></div>
              </div>
              <div className="acciones">
                <button className="btn btn-primario" onClick={() => onCargar(e)}>Cargar</button>
                <button className="btn btn-contorno" onClick={() => onEliminar(e.numero)}>Eliminar</button>
              </div>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
