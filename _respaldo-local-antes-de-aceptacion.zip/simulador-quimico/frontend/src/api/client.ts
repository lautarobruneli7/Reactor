import type { ComponenteEnReactor, Compuesto, Especificacion, Reaccion, SimulacionSalida } from '../types';

const BASE = import.meta.env.VITE_API_URL ?? '/api';

async function pedir<T>(ruta: string, init?: RequestInit): Promise<T> {
  const r = await fetch(`${BASE}${ruta}`, {
    headers: { 'Content-Type': 'application/json' },
    ...init,
  });
  if (!r.ok) {
    let detalle = r.statusText;
    try {
      const j = await r.json();
      if (typeof j.detail === 'string') detalle = j.detail;
    } catch {
      /* respuesta sin JSON */
    }
    throw new Error(`Error ${r.status}: ${detalle}`);
  }
  return r.json() as Promise<T>;
}

export function obtenerCompuestos(): Promise<Compuesto[]> {
  return pedir<Compuesto[]>('/compuestos');
}

export function obtenerReacciones(): Promise<Reaccion[]> {
  return pedir<Reaccion[]>('/reacciones');
}

export function simular(
  componentes: ComponenteEnReactor[],
  reaccionId: string,
  rendimientoReal: number | null,
  signal?: AbortSignal,
): Promise<SimulacionSalida> {
  return pedir<SimulacionSalida>('/simulacion', {
    method: 'POST',
    signal,
    body: JSON.stringify({
      componentes: componentes.map(({ id, gramos, pureza }) => ({ id, gramos, pureza })),
      reaccion_id: reaccionId,
      rendimiento_real_pct: rendimientoReal,
    }),
  });
}

export function obtenerEspecificaciones(): Promise<Especificacion[]> {
  return pedir<Especificacion[]>('/especificaciones');
}

export function obtenerPropiedades(id: string): Promise<Record<string, number | string>> {
  return pedir<Record<string, number | string>>(`/compuestos/${id}/propiedades`);
}
