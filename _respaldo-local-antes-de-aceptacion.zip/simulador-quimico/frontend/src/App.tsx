import { useCallback, useEffect, useRef, useState } from 'react';
import { obtenerCompuestos, obtenerEspecificaciones, obtenerReacciones } from './api/client';
import { BibliotecaVista } from './components/Biblioteca/BibliotecaVista';
import { Catalogo } from './components/Compuestos/Catalogo';
import { EnsayosVista } from './components/Ensayos/EnsayosVista';
import { Cabecera, type Seccion } from './components/Layout/Cabecera';
import { Reactor } from './components/Reactor/Reactor';
import { minimoDePureza, Resultados } from './components/Resultados/Resultados';
import { useEnsayos } from './hooks/useEnsayos';
import { useSimulacion } from './hooks/useSimulacion';
import type { ComponenteEnReactor, Compuesto, Ensayo, Reaccion } from './types';

// Misma mezcla del botón "Cargar ejemplo" de los prototipos: puntaje esperado = 85.
const EJEMPLO: Array<[string, number, number]> = [
  ['ibb', 134, 99],
  ['aa', 102, 98],
  ['cat', 20, 97],
  ['h2', 2, 99],
  ['co', 28, 98],
  ['exc', 30, 99],
];

const REACCION_INICIAL = 'ibuprofeno-simplificada';

/** Mezcla de ejemplo de una reacción: 1 mol de cada reactivo (en la proporción de la ecuación) y un poco de catalizador. */
function ejemploDe(r: Reaccion, catalogo: Compuesto[]): Array<[string, number, number]> {
  if (r.id === REACCION_INICIAL) return EJEMPLO;
  const pm = (id: string) => catalogo.find((c) => c.id === id)?.pm ?? 0;
  const lista: Array<[string, number, number]> = r.reactivos.map((x) => [x.id, Math.min(400, Math.max(1, Math.round(x.coef * pm(x.id)))), 98]);
  if (r.catalizador) lista.push([r.catalizador, 5, 98]);
  return lista;
}

export default function App() {
  const [seccion, setSeccion] = useState<Seccion>('reactor');
  const [catalogo, setCatalogo] = useState<Compuesto[]>([]);
  const [minimoPureza, setMinimoPureza] = useState<number | null>(null);
  const [errorCatalogo, setErrorCatalogo] = useState<string | null>(null);
  const [componentes, setComponentes] = useState<ComponenteEnReactor[]>([]);
  const [reacciones, setReacciones] = useState<Reaccion[]>([]);
  const [reaccionId, setReaccionId] = useState(REACCION_INICIAL);
  const [rendimientoReal, setRendimientoReal] = useState<number | null>(null);
  const [guardadoReciente, setGuardadoReciente] = useState(false);
  const siguienteUid = useRef(1);
  const { ensayos, siguiente, guardar, eliminar } = useEnsayos();

  useEffect(() => {
    obtenerCompuestos()
      .then(setCatalogo)
      .catch((e: unknown) => setErrorCatalogo(e instanceof Error ? e.message : 'Error desconocido'));
    obtenerReacciones()
      .then(setReacciones)
      .catch(() => setReacciones([]));
    obtenerEspecificaciones()
      .then((esp) => setMinimoPureza(minimoDePureza(esp)))
      .catch(() => setMinimoPureza(null));
  }, []);

  const { salida, error, cargando } = useSimulacion(componentes, reaccionId, rendimientoReal);
  const reaccion = reacciones.find((r) => r.id === reaccionId) ?? null;
  const idProducto = reaccion?.productos.find((p) => p.principal)?.id;
  const producto = catalogo.find((c) => c.id === idProducto)?.nombre ?? 'Ibuprofeno';

  const cambiarReaccion = (id: string) => {
    setReaccionId(id);
    setComponentes([]);
    setRendimientoReal(null);
  };
  const resultado = salida?.resultado ?? null;

  const agregar = useCallback(
    (id: string) => {
      if (!catalogo.some((c) => c.id === id)) return;
      setComponentes((prev) =>
        prev.some((x) => x.id === id)
          ? prev
          : [...prev, { uid: siguienteUid.current++, id, gramos: 100, pureza: 98 }],
      );
    },
    [catalogo],
  );

  const cambiar = useCallback(
    (uid: number, cambios: Partial<Pick<ComponenteEnReactor, 'gramos' | 'pureza'>>) =>
      setComponentes((prev) => prev.map((x) => (x.uid === uid ? { ...x, ...cambios } : x))),
    [],
  );

  const quitar = useCallback(
    (uid: number) => setComponentes((prev) => prev.filter((x) => x.uid !== uid)),
    [],
  );

  const cargarEjemplo = () =>
    setComponentes(
      (reaccion ? ejemploDe(reaccion, catalogo) : EJEMPLO).map(([id, gramos, pureza]) => ({ uid: siguienteUid.current++, id, gramos, pureza })),
    );

  const guardarEnsayo = () => {
    guardar({
      reaccion_id: reaccionId,
      componentes: componentes.map(({ id, gramos, pureza }) => ({ id, gramos, pureza })),
      puntaje: resultado?.puntaje ?? null,
      categoria: resultado?.categoria ?? null,
      rendimiento_pct: resultado?.rendimiento_pct ?? null,
      pureza_producto_pct: resultado?.pureza_producto_pct ?? null,
    });
    setGuardadoReciente(true);
    setTimeout(() => setGuardadoReciente(false), 1800);
  };

  const cargarEnsayo = (e: Ensayo) => {
    setReaccionId(e.reaccion_id ?? REACCION_INICIAL);
    setRendimientoReal(null);
    setComponentes(e.componentes.map((x) => ({ ...x, uid: siguienteUid.current++ })));
    setSeccion('reactor');
  };

  return (
    <div className="app">
      <Cabecera
        seccion={seccion}
        onSeccion={setSeccion}
        numero={siguiente}
        producto={producto}
        onGuardar={guardarEnsayo}
        puedeGuardar={componentes.length > 0}
        avisoGuardado={guardadoReciente}
      />

      {errorCatalogo && (
        <div className="alerta bad aviso-global">
          No se pudo cargar la biblioteca: {errorCatalogo}. ¿Está corriendo el backend (puerto 8000)?
        </div>
      )}

      <main>
        {seccion === 'reactor' && (
          <div className="vista-reactor">
            <Catalogo
              compuestos={catalogo}
              usados={componentes.map((x) => x.id)}
              onAgregar={agregar}
              onAbrirBiblioteca={() => setSeccion('biblioteca')}
            />
            <Reactor
              numero={siguiente}
              componentes={componentes}
              catalogo={catalogo}
              resultado={resultado}
              reacciones={reacciones}
              reaccion={reaccion}
              onReaccion={cambiarReaccion}
              onAgregar={agregar}
              onCambiar={cambiar}
              onQuitar={quitar}
              onEjemplo={cargarEjemplo}
              onVaciar={() => setComponentes([])}
            />
            <Resultados
              resultado={resultado}
              alertas={salida?.alertas ?? []}
              cargando={cargando}
              error={error}
              minimoPureza={minimoPureza}
              producto={producto}
              rendimientoReal={rendimientoReal}
              onRendimientoReal={setRendimientoReal}
            />
          </div>
        )}

        {seccion === 'biblioteca' && (
          <BibliotecaVista
            compuestos={catalogo}
            usados={componentes.map((x) => x.id)}
            onAgregar={agregar}
            onIrReactor={() => setSeccion('reactor')}
          />
        )}

        {seccion === 'ensayos' && (
          <EnsayosVista ensayos={ensayos} catalogo={catalogo} onCargar={cargarEnsayo} onEliminar={eliminar} />
        )}
      </main>

      <footer>
        Herramienta de estimación con datos simplificados; no reemplaza ensayos de laboratorio. El puntaje mide la
        calidad de la mezcla (pureza, rendimiento, balance estequiométrico), no la eficacia clínica. Los valores
        deben validarse con fuentes oficiales (USP, Ph. Eur.) y un profesional del área.
      </footer>
    </div>
  );
}
