// Tipos que reflejan los esquemas del backend (backend/app/models/schemas.py).

export type TipoCompuesto = 'reactivo' | 'catalizador' | 'excipiente' | 'solvente' | 'principio_activo';
export type FaseCompuesto = 'líquido' | 'sólido' | 'gas';

export interface Compuesto {
  id: string;
  nombre: string;
  rol: string;
  tipo: TipoCompuesto;
  /** Categoría de la biblioteca (Ácidos, Solventes, Gases...). */
  categoria: string;
  fase: FaseCompuesto;
  /** g/mol; 0 si no aplica (polímeros). */
  pm: number;
  pm_aplicable: boolean;
  smiles: string | null;
  formula: string | null;
  cas: string | null;
  tm_c: number | null;
  tb_c: number | null;
  sinonimos: string[];
  nota: string;
  /** "controlado" = sustancia fiscalizada (RENPRE); ver `regulacion`. */
  acceso: 'libre' | 'controlado';
  regulacion: string | null;
  /** false si fórmula y peso molecular no se pudieron contrastar con la base pública. */
  verificado: boolean;
  fuente: string;
}

export interface ParticipanteReaccion {
  id: string;
  coef: number;
  principal?: boolean;
}

export interface Reaccion {
  id: string;
  nombre: string;
  descripcion: string;
  categoria: string;
  reactivos: ParticipanteReaccion[];
  productos: ParticipanteReaccion[];
  catalizador: string | null;
  excipiente: string | null;
  ecuacion: string;
  balanceada: boolean;
  estado_validacion: string;
}

/** Un compuesto ya colocado en el reactor, con sus cantidades. */
export interface ComponenteEnReactor {
  uid: number;
  id: string;
  gramos: number;
  pureza: number;
}

export type TipoAlerta = 'ok' | 'warn' | 'bad';

export interface Alerta {
  tipo: TipoAlerta;
  mensaje: string;
}

export interface Resultado {
  puntaje: number;
  categoria: string;
  rendimiento_pct: number;
  pureza_producto_pct: number;
  balance_pct: number;
  reactivo_limitante: string;
  gramos_teoricos: number;
  gramos_estimados: number;
  pm_producto: number;
  pct_principio_activo: number | null;
  cumple_pureza: boolean;
  reaccion_id: string;
  reaccion_nombre: string;
  ecuacion: string;
  economia_atomica_pct: number | null;
  moles_reaccion: number | null;
  /** "experimental" si el rendimiento lo informó el usuario en lugar de estimarlo el modelo. */
  rendimiento_origen: 'modelo' | 'experimental';
  reactivos: Array<{
    id: string; nombre: string; coef: number; gramos_cargados: number; moles_utiles: number;
    exceso_pct: number; gramos_consumidos: number; gramos_sobrantes: number; limitante: boolean;
  }>;
  productos: Array<{
    id: string; nombre: string; coef: number; principal: boolean; pm: number;
    gramos_teoricos: number; gramos_estimados: number;
  }>;
}

export interface SimulacionSalida {
  resultado: Resultado | null;
  alertas: Alerta[];
}

export interface Especificacion {
  id: string;
  producto: string;
  parametro: string;
  minimo: number | null;
  maximo: number | null;
  unidad: string;
  fuente: string;
  estado: string;
}

/** Un ensayo guardado: la mezcla y una foto de sus resultados. */
export interface Ensayo {
  numero: number;
  fecha: string;
  /** Reacción con la que se hizo el ensayo (los guardados antes no la traen: era el ibuprofeno). */
  reaccion_id?: string;
  componentes: Array<Pick<ComponenteEnReactor, 'id' | 'gramos' | 'pureza'>>;
  puntaje: number | null;
  categoria: string | null;
  rendimiento_pct: number | null;
  pureza_producto_pct: number | null;
}
