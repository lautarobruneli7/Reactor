from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api import routes_calculos, routes_compuestos, routes_elementos, routes_simulacion
from app.core.propiedades import rdkit_disponible
from app.db.database import init_db
from app.db.seed import cargar_datos


@asynccontextmanager
async def lifespan(_: FastAPI):
    init_db()
    cargar_datos()
    yield


app = FastAPI(
    title="Simulador Químico",
    description="Estimación de rendimiento, pureza y calidad de mezclas para las reacciones del catálogo (ejemplo principal: ibuprofeno). "
    "No reemplaza ensayos de laboratorio.",
    version="0.2.0",
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173", "http://127.0.0.1:5173"],
    allow_methods=["*"],
    expose_headers=["X-Total-Count"],
    allow_headers=["*"],
)

app.include_router(routes_compuestos.router, prefix="/api")
app.include_router(routes_elementos.router, prefix="/api")
app.include_router(routes_calculos.router, prefix="/api")
app.include_router(routes_simulacion.router, prefix="/api")


@app.get("/api/salud", tags=["sistema"])
def salud():
    return {"estado": "ok", "rdkit": rdkit_disponible()}
