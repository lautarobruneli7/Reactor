from fastapi import APIRouter, HTTPException

from app.core import reacciones as util_reacciones
from app.core.simulador import REACCION_POR_DEFECTO, ComponenteDesconocido, simular
from app.db import database
from app.models.schemas import ReaccionDetalle, SimulacionEntrada, SimulacionSalida

router = APIRouter(tags=["simulacion"])


def _catalogo() -> dict:
    return {c.id: c for c in database.listar_compuestos()}


def _reaccion_o_404(id_: str):
    r = database.obtener_reaccion(id_)
    if r is None:
        raise HTTPException(status_code=404, detail=f"Reacción desconocida: {id_}")
    return r


@router.get("/reacciones", response_model=list[ReaccionDetalle])
def listar_reacciones(compuesto: str | None = None):
    """Reacciones disponibles. Con `compuesto` se listan solo las que lo usan (reactivo, producto o catalizador)."""
    catalogo = _catalogo()
    return [util_reacciones.detallar(r, catalogo) for r in database.listar_reacciones(compuesto)]


@router.get("/reacciones/{reaccion_id}", response_model=ReaccionDetalle)
def obtener_reaccion(reaccion_id: str):
    return util_reacciones.detallar(_reaccion_o_404(reaccion_id), _catalogo())


@router.get("/reaccion", response_model=ReaccionDetalle)
def reaccion_activa(id: str = REACCION_POR_DEFECTO):
    """Reacción y parámetros del modelo en uso (para mostrarlos y auditarlos). Por defecto, la del ibuprofeno."""
    return util_reacciones.detallar(_reaccion_o_404(id), _catalogo())


@router.post("/simulacion", response_model=SimulacionSalida)
def simulacion(entrada: SimulacionEntrada):
    reaccion = _reaccion_o_404(entrada.reaccion_id)
    try:
        return simular(entrada.componentes, _catalogo(), reaccion, entrada.rendimiento_real_pct)
    except ComponenteDesconocido as e:
        raise HTTPException(status_code=404, detail=str(e))
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))
