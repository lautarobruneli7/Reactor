"""Esquemas Pydantic: entrada/salida de la API y datos del catálogo."""
from typing import Literal

from pydantic import BaseModel, Field, model_validator

TipoCompuesto = Literal["reactivo", "catalizador", "excipiente", "solvente", "principio_activo"]
FaseCompuesto = Literal["líquido", "sólido", "gas"]
TipoAlerta = Literal["ok", "warn", "bad"]
AccesoCompuesto = Literal["libre", "controlado"]


# ---------- Tabla periódica ----------
class Elemento(BaseModel):
    numero: int
    simbolo: str
    nombre: str
    nombre_en: str
    masa_atomica: float
    grupo: int | None = None
    periodo: int
    categoria: str
    fase_25c: FaseCompuesto | None = None
    radiactivo: bool = False
    fuente: str = ""


# ---------- Catálogo ----------
class Compuesto(BaseModel):
    id: str
    nombre: str
    rol: str
    tipo: TipoCompuesto
    categoria: str
    fase: FaseCompuesto
    formula: str | None = None
    formula_hill: str | None = None
    cas: str | None = None
    pm: float = Field(ge=0, description="Peso molecular en g/mol (0 si no aplica, p. ej. polímeros)")
    pm_aplicable: bool = True
    smiles: str | None = None
    inchikey: str | None = None
    pubchem_cid: int | None = None
    tm_c: float | None = Field(default=None, description="Punto de fusión en °C")
    tb_c: float | None = Field(default=None, description="Punto de ebullición en °C")
    sinonimos: list[str] = Field(default_factory=list)
    nota: str = ""
    acceso: AccesoCompuesto = "libre"
    regulacion: str | None = None
    verificado: bool = True
    fuente: str = ""


class Especificacion(BaseModel):
    id: str
    producto: str
    parametro: str
    minimo: float | None = None
    maximo: float | None = None
    unidad: str = ""
    fuente: str = ""
    estado: str = ""


# ---------- Reacción y parámetros del modelo ----------
class PesosPuntaje(BaseModel):
    rendimiento: float = 0.35
    pureza: float = 0.45
    balance: float = 0.20


class ParametrosModelo(BaseModel):
    """Parámetros del modelo de rendimiento y calidad.

    Los valores por defecto son los GENÉRICOS del prototipo (sin validar). Una
    reacción puede sobreescribir solo los que tenga fundamentados. Si no define
    `catalizador_ratio_optimo`, el catalizador no penaliza por cantidad.
    """

    catalizador_requerido: bool = False
    catalizador_ratio_optimo: float | None = None
    catalizador_ratio_minimo: float = 0.08
    catalizador_ratio_maximo: float = 0.30
    pendiente_catalizador: float = 0.35
    factor_catalizador_minimo: float = 0.4
    factor_catalizador_ausente: float = 0.5
    rendimiento_base: float = 0.85
    rendimiento_maximo: float = 0.95
    exceso_tolerado: float = 0.1
    exceso_alerta: float = 0.25
    pendiente_exceso: float = 0.3
    factor_exceso_minimo: float = 0.6
    penalizacion_impureza: float = 1.6
    penalizacion_catalizador_pureza: float = 4.0
    pureza_producto_minima: float = 80
    pureza_producto_maxima: float = 99.9
    pureza_especificada_minima: float = 98.5
    pesos_puntaje: PesosPuntaje = Field(default_factory=PesosPuntaje)


class Participante(BaseModel):
    id: str
    coef: int = Field(ge=1, description="Coeficiente estequiométrico")


class ProductoReaccion(Participante):
    principal: bool = False


class Reaccion(BaseModel):
    id: str
    nombre: str
    descripcion: str = ""
    categoria: str = ""
    reactivos: list[Participante]
    productos: list[ProductoReaccion]
    catalizador: str | None = None
    excipiente: str | None = None
    parametros: ParametrosModelo = Field(default_factory=ParametrosModelo)
    fuente: str = ""
    estado_validacion: str = ""

    @model_validator(mode="after")
    def _un_principal(self):
        if sum(1 for p in self.productos if p.principal) != 1:
            raise ValueError(f"La reacción {self.id} debe tener exactamente un producto principal")
        if not self.reactivos:
            raise ValueError(f"La reacción {self.id} no tiene reactivos")
        return self

    @property
    def principal(self) -> ProductoReaccion:
        return next(p for p in self.productos if p.principal)


class ReaccionDetalle(Reaccion):
    """Reacción con datos calculados para mostrarla (ecuación y comprobación de balance)."""

    ecuacion: str = ""
    balanceada: bool = True
    producto: dict | None = None  # producto principal (compatibilidad con la versión anterior de la API)


# ---------- Simulación ----------
class ComponenteEntrada(BaseModel):
    id: str
    gramos: float = Field(ge=0, le=1_000_000)
    pureza: float = Field(ge=0, le=100, description="Pureza del insumo en %")


class SimulacionEntrada(BaseModel):
    componentes: list[ComponenteEntrada] = Field(default_factory=list)
    reaccion_id: str = "ibuprofeno-simplificada"
    rendimiento_real_pct: float | None = Field(
        default=None,
        ge=0,
        le=100,
        description="Rendimiento medido en un ensayo real; si se informa, reemplaza al estimado por el modelo.",
    )


class Alerta(BaseModel):
    tipo: TipoAlerta
    mensaje: str


class ReactivoResultado(BaseModel):
    id: str
    nombre: str
    coef: int
    gramos_cargados: float
    moles_utiles: float
    exceso_pct: float
    gramos_consumidos: float
    gramos_sobrantes: float
    limitante: bool


class ProductoResultado(BaseModel):
    id: str
    nombre: str
    coef: int
    principal: bool
    pm: float
    gramos_teoricos: float
    gramos_estimados: float


class Resultado(BaseModel):
    puntaje: int = Field(ge=0, le=100)
    categoria: str
    rendimiento_pct: float
    pureza_producto_pct: float
    balance_pct: float
    reactivo_limitante: str
    gramos_teoricos: float
    gramos_estimados: float
    pm_producto: float
    pct_principio_activo: float | None = None
    cumple_pureza: bool
    # --- ampliaciones (la versión anterior de la API no las traía)
    reaccion_id: str = ""
    reaccion_nombre: str = ""
    ecuacion: str = ""
    economia_atomica_pct: float | None = None
    moles_reaccion: float | None = None
    rendimiento_origen: Literal["modelo", "experimental"] = "modelo"
    reactivos: list[ReactivoResultado] = Field(default_factory=list)
    productos: list[ProductoResultado] = Field(default_factory=list)


class SimulacionSalida(BaseModel):
    resultado: Resultado | None
    alertas: list[Alerta]


# ---------- Utilidades de cálculo ----------
class EntradaBalanceo(BaseModel):
    reactivos: list[str] = Field(min_length=1, max_length=12)
    productos: list[str] = Field(min_length=1, max_length=12)
